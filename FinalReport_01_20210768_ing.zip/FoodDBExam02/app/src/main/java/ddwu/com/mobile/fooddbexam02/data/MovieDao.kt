package ddwu.com.mobile.fooddbexam02.data

import android.provider.MediaStore

class MovieDao {
}